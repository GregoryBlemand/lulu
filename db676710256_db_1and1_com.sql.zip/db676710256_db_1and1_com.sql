-- phpMyAdmin SQL Dump
-- version 4.1.14.8
-- http://www.phpmyadmin.net
--
-- Client :  db676710256.db.1and1.com
-- Généré le :  Jeu 06 Avril 2017 à 13:19
-- Version du serveur :  5.5.54-0+deb7u2-log
-- Version de PHP :  5.4.45-0+deb7u8

SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `db676710256`
--

-- --------------------------------------------------------

--
-- Structure de la table `galerie`
--

CREATE TABLE IF NOT EXISTS `galerie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` longtext,
  `private` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) TYPE=InnoDB  AUTO_INCREMENT=32 ;

--
-- Contenu de la table `galerie`
--

INSERT INTO `galerie` (`id`, `title`, `description`, `private`) VALUES
(20, 'Mariages', '<p><span style="font-size: 12pt;">On le dit souvent et c''est une r&eacute;alit&eacute; :</span></p>\r\n<p><span style="font-size: 12pt;">&nbsp;</span></p>\r\n<p style="text-align: center;"><span style="font-size: 12pt;">" Le <strong>jour de votre mariage</strong></span></p>\r\n<p style="text-align: center;"><span style="font-size: 12pt;">se pr&eacute;pare longtemps</span></p>\r\n<p style="text-align: center;"><span style="font-size: 12pt;">et <strong>passe en un instant !</strong> "</span></p>\r\n<p style="text-align: center;"><span style="font-size: 12pt;">&nbsp;</span></p>\r\n<p style="text-align: left;"><span style="font-size: 12pt;">Je suis l&agrave; pour <strong>fixer<span class="Style10">&nbsp;</span>les plus beaux instants</strong> de cette&nbsp;journ&eacute;e exceptionnelle.</span></p>\r\n<p><span style="font-size: 12pt;">Les services que je propose :&nbsp;</span></p>\r\n<table style="height: 308px; width: 80%; margin-left: auto; margin-right: auto;" border="1px" cellpadding="10px">\r\n<tbody>\r\n<tr>\r\n<td style="width: 236px;"><span style="font-size: 12pt;">Formules</span></td>\r\n<td style="width: 130px; text-align: center;"><span style="font-size: 12pt;">Standard</span></td>\r\n<td style="width: 127px; text-align: center;"><span style="font-size: 12pt;">Premium</span></td>\r\n</tr>\r\n<tr>\r\n<td style="width: 236px;"><span style="font-size: 12pt;">Reportage des pr&eacute;paratifs</span></td>\r\n<td style="width: 130px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #ff0000;">non</span></strong></span></td>\r\n<td style="width: 127px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #339966;">oui</span></strong></span></td>\r\n</tr>\r\n<tr>\r\n<td style="width: 236px;"><span style="font-size: 12pt;">photos de couple</span></td>\r\n<td style="width: 130px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #339966;">oui</span></strong></span></td>\r\n<td style="width: 127px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #339966;">oui</span></strong></span></td>\r\n</tr>\r\n<tr>\r\n<td style="width: 236px;"><span style="font-size: 12pt;">reportage de la c&eacute;r&eacute;monie civile et/ou religieuse</span></td>\r\n<td style="width: 130px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #339966;">oui</span></strong></span></td>\r\n<td style="width: 127px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #339966;">oui</span></strong></span></td>\r\n</tr>\r\n<tr>\r\n<td style="width: 236px;"><span style="font-size: 12pt;">photos de famille</span></td>\r\n<td style="width: 130px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #339966;">oui</span></strong></span></td>\r\n<td style="width: 127px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #339966;">oui</span></strong></span></td>\r\n</tr>\r\n<tr>\r\n<td style="width: 236px;"><span style="font-size: 12pt;">reportage du cocktail</span></td>\r\n<td style="width: 130px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #ff0000;">non</span></strong></span></td>\r\n<td style="width: 127px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #339966;">oui</span></strong></span></td>\r\n</tr>\r\n<tr>\r\n<td style="width: 236px;"><span style="font-size: 12pt;">tour de table des invit&eacute;s</span></td>\r\n<td style="width: 130px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #ff0000;">non</span></strong></span></td>\r\n<td style="width: 127px; text-align: center;"><span style="font-size: 12pt;"><strong><span style="color: #339966;">oui</span></strong></span></td>\r\n</tr>\r\n<tr>\r\n<td style="width: 236px;"><span style="font-size: 12pt;">Prix (Hors transport)</span></td>\r\n<td style="width: 130px; text-align: center;"><span style="font-size: 12pt;">750&euro;</span></td>\r\n<td style="width: 127px; text-align: center;"><span style="font-size: 12pt;">950&euro;</span></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p style="text-align: center;"><span style="font-size: 12pt;">&nbsp;</span></p>\r\n<p>&nbsp;</p>\r\n<p style="text-align: left;"><span style="font-size: 12pt;">Bien entendu, nous discuterons ensemble de ces prestations pour les adapter &agrave; vos envies et &agrave; votre budget. Contactez-moi pour plus de renseignements.</span></p>\r\n<p style="text-align: left;">&nbsp;</p>\r\n<p style="text-align: left;"><span style="font-size: 12pt;">Une fois <strong>cette merveilleuse journ&eacute;e</strong> termin&eacute;e, je vous livre <strong>les photos que vous d&eacute;sirez</strong> (retouch&eacute;es par mes soins) en haute d&eacute;finition sur cl&eacute; USB.</span></p>\r\n<p style="text-align: left;">&nbsp;</p>\r\n<p style="text-align: left;">&nbsp;</p>\r\n<p style="text-align: left;"><span style="font-size: 12pt;">Je peux &eacute;galement r&eacute;aliser un <strong>livre-photos</strong> (sur devis) pour que vous puissiez feuilleter <strong>ces moments si pr&eacute;cieux</strong>.</span></p>\r\n<p style="text-align: left;"><span style="font-size: 12pt;">Vous aurez la possibilit&eacute; de voir la maquette avant la fabrication. Les tirages des pages du livre sont r&eacute;alis&eacute;s sur du <span class="Style10">papier photo argentique</span> haute qualit&eacute;.</span></p>\r\n<p style="text-align: left;"><span style="font-size: 12pt;">Je propose la <strong>cr&eacute;ation de faire-part</strong> et cartes de remerciement : 45&euro; de cr&eacute;ation + 0,80cts de faire part</span></p>', 0),
(25, 'Portraits', '<p>Un portrait de vous, en couple, en famille, le suivi de votre grossesse, la naissance de votre enfant, un anniversaire, je suis &agrave; votre &eacute;coute pour <span class="Style10">fixer les moments forts</span> de votre vie.</p>\r\n<p>Je vous propose diff&eacute;rentes formules :</p>\r\n<p><span class="Style2">Formule &agrave; 150&euro;</span> (en int&eacute;rieur ou ext&eacute;rieur) : Une s&eacute;ance de prises de vues (dur&eacute;e variable selon l''&acirc;ge des mod&egrave;les)+ Un CD haute d&eacute;finition de 25 photos optimis&eacute;es(choisies parmi toutes celles de la s&eacute;ance).</p>\r\n<p><span class="Style2">Formule &agrave; 200&euro;</span> (en int&eacute;rieur ou ext&eacute;rieur) : Une s&eacute;ance de prises de vues (dur&eacute;e variable selon l''&acirc;ge des mod&egrave;les) + Un CD haute d&eacute;finition de 25 photos optimis&eacute;es(choisies parmi toutes celles de la s&eacute;ance) + Un livre 20x25 de 25 photos.</p>\r\n<p><span class="Style2">Formule &agrave; 275 &euro;</span> (en int&eacute;rieur ou ext&eacute;rieur) : Deux s&eacute;ances de prises de vues (dur&eacute;e variable selon l''&acirc;ge des mod&egrave;les) + Un CD haute d&eacute;finition de 60 photos optimis&eacute;es(choisies parmi toutes celles de la s&eacute;ance).</p>\r\n<p><span class="Style2">Formule &agrave; 325 &euro;</span> (en int&eacute;rieur ou ext&eacute;rieur) : Deux s&eacute;ances de prises de vues (dur&eacute;e variable selon l''&acirc;ge des mod&egrave;les) + Un CD haute d&eacute;finition de 60 photos optimis&eacute;es(choisies parmi toutes celles de la s&eacute;ance) + Un livre 20x25 de 35 photos.</p>\r\n<p><span class="Style2">Option </span>: L''int&eacute;gralit&eacute; des images de votre s&eacute;ance en format num&eacute;rique 170&euro; par s&eacute;ance</p>\r\n<p>La mise en page des livres est r&eacute;alis&eacute;e par mes soins, vous aurez la possibilit&eacute; de voir la maquette avant la fabrication. Les tirages des pages du livre sont r&eacute;alis&eacute;s sur du <span class="Style10">papier photo argentique</span> haute qualit&eacute;. Je r&eacute;alise &eacute;galement des <span class="Style10">faire part</span>, cartes de remerciement, p&ecirc;le-m&ecirc;le.</p>\r\n<p>Ces formules sont bien s&ucirc;re <span class="Style10">adaptables</span> selon vos envies et votre budget, n''h&eacute;sitez pas &agrave; me contacter pour plus de renseignements.</p>', 0),
(26, 'Reportages', '<p>Besoin de photos pour promouvoir l''image de votre entreprise, de votre groupe de musique, de votre compagnie de th&eacute;&acirc;tre, mettre en valeur votre travail et vos produits ? n''h&eacute;sitez pas &agrave; me contacter pour plus d''informations.</p>', 0);

-- --------------------------------------------------------

--
-- Structure de la table `galerie_image`
--

CREATE TABLE IF NOT EXISTS `galerie_image` (
  `galerie_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  PRIMARY KEY (`galerie_id`,`image_id`),
  KEY `IDX_94BB0BC9825396CB` (`galerie_id`),
  KEY `IDX_94BB0BC93DA5256D` (`image_id`)
) TYPE=InnoDB;

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `galerie_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C53D045F825396CB` (`galerie_id`)
) TYPE=InnoDB  AUTO_INCREMENT=369 ;

--
-- Contenu de la table `image`
--

INSERT INTO `image` (`id`, `url`, `alt`, `galerie_id`) VALUES
(66, 'b695a8d82c5664c1bbeffba8153f61f7.jpeg', 'Lucile Ortega - Photographie', 20),
(67, '34b1345632f20e871489f2f51347bf16.jpeg', 'Lucile Ortega - Photographie', 20),
(68, 'e1d3cc0c47be647937fd8c98671628a7.jpeg', 'Lucile Ortega - Photographie', 20),
(69, '9c565e9d7cebe907471cf15b8fe97ffb.jpeg', 'Lucile Ortega - Photographie', 20),
(70, '54a25b22f82738f899c69ae21339595f.jpeg', 'Lucile Ortega - Photographie', 20),
(71, 'e827f400f1472725321062080cb49046.jpeg', 'Lucile Ortega - Photographie', 20),
(72, 'e174e7edf6180e5938177e3d059a2908.jpeg', 'Lucile Ortega - Photographie', 20),
(73, 'f866a313fa32a8e40cd7052161060424.jpeg', 'Lucile Ortega - Photographie', 20),
(74, '0fb4e2e64cf84af76c2b6ac9bafb8bd0.jpeg', 'Lucile Ortega - Photographie', 20),
(75, 'ca200e12e4cf6e90893278497e5c6c04.jpeg', 'Lucile Ortega - Photographie', 20),
(76, 'a12e815dee1a7de75ea1422aa0c364bb.jpeg', 'Lucile Ortega - Photographie', 20),
(77, '196142da8815e1705ca08f5e67e3d444.jpeg', 'Lucile Ortega - Photographie', 20),
(78, '5782b844fd1e0290fec3e253238ab6e8.jpeg', 'Lucile Ortega - Photographie', 20),
(79, 'caec8232d371b68b9dc94879623e1ae5.jpeg', 'Lucile Ortega - Photographie', 20),
(80, 'db7ce6fc776c1523664952b268ecb3eb.jpeg', 'Lucile Ortega - Photographie', 20),
(81, '4474069bf96e4da5505dbfcbf0c3bd39.jpeg', 'Lucile Ortega - Photographie', 20),
(82, '640fa36cdc4d3e826d61a579f45c258e.jpeg', 'Lucile Ortega - Photographie', 20),
(83, 'ba452b73b504756c46da33136995b8ab.jpeg', 'Lucile Ortega - Photographie', 20),
(84, '466917ded8463753a4c5189f7cf0a43a.jpeg', 'Lucile Ortega - Photographie', 20),
(85, 'e50fc488a5f527ec193c0b515da38c0f.jpeg', 'Lucile Ortega - Photographie', 20),
(86, '67524d78d5a3023d98ebc8965b894739.jpeg', 'Lucile Ortega - Photographie', 20),
(87, 'e357a17e2bec48f624c0f745a0eed936.jpeg', 'Lucile Ortega - Photographie', 20),
(88, 'd2c57d543f7d472d7cee2f53d4da3b6f.jpeg', 'Lucile Ortega - Photographie', 20),
(89, '947611cdb3b637b86ecfaafb797d3abd.jpeg', 'Lucile Ortega - Photographie', 20),
(90, '288564b88c4d081f3b1ea8859863e093.jpeg', 'Lucile Ortega - Photographie', 20),
(91, '0d6b0ae5aebaebf26e0a1eee8fc3920e.jpeg', 'Lucile Ortega - Photographie', 20),
(92, 'dcc31bc217883ff537289c78dc25804a.jpeg', 'Lucile Ortega - Photographie', 20),
(93, '89ccbfdfb72c6b7ca6fc6e1fb7690fb0.jpeg', 'Lucile Ortega - Photographie', 20),
(94, '7391fa6d6e9848fb2f62f9f7134a5b41.jpeg', 'Lucile Ortega - Photographie', 20),
(95, '38a87c85a2846b6b7f886404c96fa1f6.jpeg', 'Lucile Ortega - Photographie', 20),
(96, 'f0e3377966afb882a1abdab19cf6011e.jpeg', 'Lucile Ortega - Photographie', 20),
(97, '127467f49f7d0942e14a44948c9a29ab.jpeg', 'Lucile Ortega - Photographie', 20),
(98, '1a4d23126fbfe32d456ac23cc6c46fc9.jpeg', 'Lucile Ortega - Photographie', 20),
(99, '113dd1a8bf9ac227623ecfa5b83201a4.jpeg', 'Lucile Ortega - Photographie', 20),
(100, '61601f130fddf31cc7c444576f471eae.jpeg', 'Lucile Ortega - Photographie', 20),
(101, '88a91cdc735017c3eddea9db8e02445c.jpeg', 'Lucile Ortega - Photographie', 20),
(102, 'c50d6e6241bad94e01d72ad2424a76a4.jpeg', 'Lucile Ortega - Photographie', 20),
(103, 'b96125e7288abaa1e5682e8d07fbfbe6.jpeg', 'Lucile Ortega - Photographie', 20),
(104, '931ceea2c7301aca2b7addcd254f3a37.jpeg', 'Lucile Ortega - Photographie', 20),
(105, 'ddb1e85360519f79467f622879c633d5.jpeg', 'Lucile Ortega - Photographie', 20),
(106, '3307d7fc249f3b58c7c887c543c7ea6c.jpeg', 'Lucile Ortega - Photographie', 20),
(107, 'e9e650f4476c2178d732e20f4e37fb36.jpeg', 'Lucile Ortega - Photographie', 20),
(108, 'cc464e206b8fcde25d785f89ba65bd6c.jpeg', 'Lucile Ortega - Photographie', 20),
(109, '3ebc2204f6ce6be4a3086de5f1c1bdfb.jpeg', 'Lucile Ortega - Photographie', 20),
(110, '3e341390fe132bab8f58fe640dbdc3c9.jpeg', 'Lucile Ortega - Photographie', 20),
(111, '162b941f1ac79a5f5a36f70fbe270e6b.jpeg', 'Lucile Ortega - Photographie', 20),
(112, '85988603c0f34d931f534598ca212351.jpeg', 'Lucile Ortega - Photographie', 20),
(113, '72b070f8118f56072d85866a4dce878b.jpeg', 'Lucile Ortega - Photographie', 20),
(114, '15822653863c4ab350c92d7693df1604.jpeg', 'Lucile Ortega - Photographie', 20),
(115, '43de961f0275c01550fc5ef8e56d677e.jpeg', 'Lucile Ortega - Photographie', 20),
(116, 'f83839b222553b080e55c9789766734e.jpeg', 'Lucile Ortega - Photographie', 20),
(117, '8a1770bd5a77a7b52fad0aac134fd444.jpeg', 'Lucile Ortega - Photographie', 20),
(118, 'c3bf44ad0b0219b9551538f7570ef52f.jpeg', 'Lucile Ortega - Photographie', 20),
(119, '0831f4e485769d1fe18d9e48e58c85f8.jpeg', 'Lucile Ortega - Photographie', 20),
(120, '377cba2f0d5317a4603f4fd8076ec6e1.jpeg', 'Lucile Ortega - Photographie', 20),
(121, 'fe85cc84485c3bfbbc9867460cd0b753.jpeg', 'Lucile Ortega - Photographie', 20),
(122, '7eb3a63f266c9c3f7113fc12a4ef7c55.jpeg', 'Lucile Ortega - Photographie', 20),
(123, '2681925832c2c75499ebe3059ea99eb4.jpeg', 'Lucile Ortega - Photographie', 20),
(124, 'cf6d14bffe851f3820c4df22b3573583.jpeg', 'Lucile Ortega - Photographie', 20),
(125, '9df855953e5d57a161e6df5079381ecf.jpeg', 'Lucile Ortega - Photographie', 20),
(126, 'efec9d22f5738c60828887b80b79b7d4.jpeg', 'Lucile Ortega - Photographie', 20),
(127, 'acd8683e5b7af2d93207bab281aab72b.jpeg', 'Lucile Ortega - Photographie', 20),
(128, 'e56e045035e139a75d310f3df29388b7.jpeg', 'Lucile Ortega - Photographie', 20),
(129, '890dd7783079f6c68eb980634b168d82.jpeg', 'Lucile Ortega - Photographie', 20),
(130, '2513a2ea4938b9db69fcd7080e5b5768.jpeg', 'Lucile Ortega - Photographie', 20),
(131, '7e611bdb3c86d17b97b714aecc5359cd.jpeg', 'Lucile Ortega - Photographie', 20),
(132, 'd4c66aedc95c095d498d05155f66a6e1.jpeg', 'Lucile Ortega - Photographie', 20),
(133, '52e576b3425c5fbb8ea17d1f34d804f7.jpeg', 'Lucile Ortega - Photographie', 20),
(134, '7906439b2b376d8d5ebdc7d8d8fa55a9.jpeg', 'Lucile Ortega - Photographie', 20),
(135, 'f867da47fda1f826c9632a167caac76a.jpeg', 'Lucile Ortega - Photographie', 20),
(136, '801a8664a6223b0cb9beb410f32b0c1f.jpeg', 'Lucile Ortega - Photographie', 20),
(137, '89d0c364b4126b1c4c7fbfce5ca43298.jpeg', 'Lucile Ortega - Photographie', 20),
(138, '3c2e7edde8bb54cbb862726a1af68591.jpeg', 'Lucile Ortega - Photographie', 20),
(139, 'd8473305be1cb071e7ec13568c439a4d.jpeg', 'Lucile Ortega - Photographie', 20),
(140, '2891bc61c3eeb569acddc529bad6c0a1.jpeg', 'Lucile Ortega - Photographie', 20),
(141, 'f88318b04b781ab533366344c7be4d5c.jpeg', 'Lucile Ortega - Photographie', 20),
(142, '2de04d175eb0569a408b462122540554.jpeg', 'Lucile Ortega - Photographie', 20),
(143, 'bd69cf58535ae1a559026c70a1fe8a90.jpeg', 'Lucile Ortega - Photographie', 20),
(144, '727084a7ec411662c615c5c80d958bc7.jpeg', 'Lucile Ortega - Photographie', 20),
(145, '4918db8f3cdb1179dac33b55d16884ad.jpeg', 'Lucile Ortega - Photographie', 20),
(146, 'ecda1ca9cb15a66100dd9db642864f24.jpeg', 'Lucile Ortega - Photographie', 20),
(147, 'b21bbb9664b96d0ffbc9ddb57586ec2e.jpeg', 'Lucile Ortega - Photographie', 20),
(148, '37b6b584b5ed589158613a5cdf249652.jpeg', 'Lucile Ortega - Photographie', 20),
(149, 'fa5b77b5ff30b7e59ed79d7c09698f93.jpeg', 'Lucile Ortega - Photographie', 20),
(150, 'bd696e726b3907d5b9bd1dce34402aae.jpeg', 'Lucile Ortega - Photographie', 20),
(151, '23ba1099b654e6aa39fef4adc1ccf3b9.jpeg', 'Lucile Ortega - Photographie', 20),
(152, 'b5547b146ce166749995d707ef74d83e.jpeg', 'Lucile Ortega - Photographie', 20),
(153, 'f4d95b75b0c7e4e1c792ae8477758a76.jpeg', 'Lucile Ortega - Photographie', 20),
(154, '67efe62eea2f841657621030bee49d88.jpeg', 'Lucile Ortega - Photographie', 20),
(155, '5bdd9496469a2434d991c821b64abbde.jpeg', 'Lucile Ortega - Photographie', 20),
(156, 'ec1142aaf223791ab6f4bb1fc0ad4812.jpeg', 'Lucile Ortega - Photographie', 20),
(157, 'af2c3acb376926582709ed704f60d563.jpeg', 'Lucile Ortega - Photographie', 20),
(158, '94e34050a0cab30f04124d2da30ce521.jpeg', 'Lucile Ortega - Photographie', 20),
(159, '6290213cc2b6fe894d0d23953835b815.jpeg', 'Lucile Ortega - Photographie', 20),
(160, '4a7f020965445f331fb55481d169d074.jpeg', 'Lucile Ortega - Photographie', 20),
(161, 'c7447b4c582b99b28c47b9930e25a7ea.jpeg', 'Lucile Ortega - Photographie', 20),
(162, 'd1ef3c5f9b7ac97a80ce5689db126abb.jpeg', 'Lucile Ortega - Photographie', 20),
(163, '2c0d864ef46f4e35abec7b3863c6a334.jpeg', 'Lucile Ortega - Photographie', 20),
(164, '9136064b988606b3dbc6becef93a0e36.jpeg', 'Lucile Ortega - Photographie', 20),
(165, 'a2003bcf4f187e57a5627eeb814a8f8a.jpeg', 'Lucile Ortega - Photographie', 20),
(166, 'f14c077d92deade82e08fb6ba12b9df0.jpeg', 'Lucile Ortega - Photographie', 20),
(167, 'e1df3048164c056fa962bdc159bb1d99.jpeg', 'Lucile Ortega - Photographie', 20),
(168, 'bde4aeb9707d1289c1232153eb2cfce4.jpeg', 'Lucile Ortega - Photographie', 20),
(169, '9c80902929afa0436d9d8b279fd3be43.jpeg', 'Lucile Ortega - Photographie', 20),
(170, 'b1d4627259294dc68812eb7da13b7e16.jpeg', 'Lucile Ortega - Photographie', 20),
(171, 'bc626963a5fd2b950cb677f39ac20e10.jpeg', 'Lucile Ortega - Photographie', 20),
(172, 'c5b024d00c3534b4959e465a3b91a55d.jpeg', 'Lucile Ortega - Photographie', 20),
(173, '005df8b956858e22e2ef758805291733.jpeg', 'Lucile Ortega - Photographie', 20),
(174, 'e0d48dcdc66442820ce543e363d6994a.jpeg', 'Lucile Ortega - Photographie', 20),
(175, 'c72a5e67d3c4d2b3bc66f627fbb67a6a.jpeg', 'Lucile Ortega - Photographie', 20),
(176, '3faa36a3ccb0af606d29932ecb41f908.jpeg', 'Lucile Ortega - Photographie', 20),
(177, 'f9698885b9d4f56e5dbd1eed6003a65b.jpeg', 'Lucile Ortega - Photographie', 20),
(178, 'b73d1479ad16a655409366b5c3dfba12.jpeg', 'Lucile Ortega - Photographie', 20),
(179, 'e1e532f4b25d76a8b68b616c226aa138.jpeg', 'Lucile Ortega - Photographie', 20),
(180, '80c9bc5a69cc97c83110657cd3caeae8.jpeg', 'Lucile Ortega - Photographie', 20),
(181, '40d7d40b37030c7cfd60f915a77bcbe1.jpeg', 'Lucile Ortega - Photographie', 20),
(182, 'b7489d4246709123441bc8dfef8d2bac.jpeg', 'Lucile Ortega - Photographie', 20),
(183, '72f2c0549fdc36c8d6665fe2b36a7eb2.jpeg', 'Lucile Ortega - Photographie', 20),
(184, 'c76b8d7a2f1a281f809b5e4319462478.jpeg', 'Lucile Ortega - Photographie', 20),
(185, 'c21945131c3a968408907363953b16c2.jpeg', 'Lucile Ortega - Photographie', 20),
(186, '17b1a0d5bbbc14a791e6bfaeb1f8085b.jpeg', 'Lucile Ortega - Photographie', 20),
(187, '4d94df8e5a2857c32e9953280c86d607.jpeg', 'Lucile Ortega - Photographie', 20),
(188, '18ae0bb40306d325072d6aa8580253eb.jpeg', 'Lucile Ortega - Photographie', 20),
(189, 'bf5af72737e36ed947b4cd1c88fe4b84.jpeg', 'Lucile Ortega - Photographie', 20),
(190, '435d267c6394242b1b5f1a9e2de8620a.jpeg', 'Lucile Ortega - Photographie', 20),
(191, 'b232c4b45dd5ac2f3b6b9213e92473cc.jpeg', 'Lucile Ortega - Photographie', 20),
(192, '3a292254e3c126851d7507c10fff2a3f.jpeg', 'Lucile Ortega - Photographie', 20),
(193, 'd1cba67ff5f9b6ebb9621a9f48688375.jpeg', 'Lucile Ortega - Photographie', 20),
(194, 'e530698f56c0d3742a59d40d89594dee.jpeg', 'Lucile Ortega - Photographie', 20),
(195, '91268d7e03138a2ee63ce965150e39de.jpeg', 'Lucile Ortega - Photographie', 20),
(196, 'a8b685250f5ac2b073057dd3e4464cb7.jpeg', 'Lucile Ortega - Photographie', 20),
(197, 'f584270b7cf46c04cb9d4f5d325eeefd.jpeg', 'Lucile Ortega - Photographie', 20),
(198, 'b9b612e479426aa459b45aa5baa12d57.jpeg', 'Lucile Ortega - Photographie', 20),
(199, '716ba90d9b83a46362dba996d182b1da.jpeg', 'Lucile Ortega - Photographie', 20),
(200, '1c6be4d3586a815a149475758ce2ea49.jpeg', 'Lucile Ortega - Photographie', 20),
(201, '236431161266fbd7235103ee4b525231.jpeg', 'Lucile Ortega - Photographie', 20),
(202, '4f9b6d623952fedb7c0ad1127c3a4b30.jpeg', 'Lucile Ortega - Photographie', 20),
(203, 'fdd52f2d01ed9a55f4aed3b18179fa59.jpeg', 'Lucile Ortega - Photographie', 20),
(204, 'bb85429180b5a8f2dfdc38d9b688c39f.jpeg', 'Lucile Ortega - Photographie', 20),
(205, 'c17898213befae3703508c6ae05d16c5.jpeg', 'Lucile Ortega - Photographie', 20),
(206, '60d05808545e459bb61baeadc6ec271c.jpeg', 'Lucile Ortega - Photographie', 20),
(207, '4f4b2f26fb9ee4365a1da38a1175af84.jpeg', 'Lucile Ortega - Photographie', 20),
(208, '08489948901d91245b5eaa52c43b6be7.jpeg', 'Lucile Ortega - Photographie', 20),
(209, '9015b3b03dcbf95ab28e794c057d7503.jpeg', 'Lucile Ortega - Photographie', 20),
(210, 'd38a1108644315d93e9534ee06a96b73.jpeg', 'Lucile Ortega - Photographie', 20),
(211, '974baa3af22ab8348370a3db50849abb.jpeg', 'Lucile Ortega - Photographie', 20),
(212, '3fc14c08045e9e092beb6c2d1b217a94.jpeg', 'Lucile Ortega - Photographie', 20),
(213, 'a8224e36b9236e47ed83ace9c61c8a14.jpeg', 'Lucile Ortega - Photographie', 20),
(214, '91f183c406a15d7a4a2df033d95dc40a.jpeg', 'Lucile Ortega - Photographie', 20),
(215, 'd3fe09191ce3b0bc9b8676b24f55e2e5.jpeg', 'Lucile Ortega - Photographie', 20),
(216, '17ade5dabd840777668be36330c7f1bf.jpeg', 'Lucile Ortega - Photographie', 20),
(217, 'efd8957f0a8a850d2a3f0b71155eec38.jpeg', 'Lucile Ortega - Photographie', 20),
(218, '1a5c829abde47b02dc18d5ea22287e5d.jpeg', 'Lucile Ortega - Photographie', 20),
(219, '249d3b5f05cb603c1f5986bc5ab98e18.jpeg', 'Lucile Ortega - Photographie', 20),
(220, 'edf910be4c121d26cc14213f38c3518f.jpeg', 'Lucile Ortega - Photographie', 20),
(221, 'c21271d971beef1dc4bbcb457f5f13b6.jpeg', 'Lucile Ortega - Photographie', 20),
(222, 'e454e171b3e8ed2aa5a683287986b6e8.jpeg', 'Lucile Ortega - Photographie', 20),
(223, '7b4bb78265031c43bc5c95b557d2f206.jpeg', 'Lucile Ortega - Photographie', 20),
(236, '4c9f953cdedea6ee93092e5a22b3091f.jpeg', 'Lucile Ortega - Photographie', 25),
(237, '3f6b70360c0bc2d2ea0e3f91c3494104.jpeg', 'Lucile Ortega - Photographie', 25),
(238, '61d8c027e938b8770434afab64d01daa.jpeg', 'Lucile Ortega - Photographie', 25),
(239, 'd080370fe4424b2d985c16f29e55edd4.jpeg', 'Lucile Ortega - Photographie', 25),
(240, 'aeba568c46e5890f0fcd96daa11b85fb.jpeg', 'Lucile Ortega - Photographie', 25),
(241, 'fd2b58ced92ce416670938e8bc1f02f8.jpeg', 'Lucile Ortega - Photographie', 25),
(242, '60b98c8e965906121e1feb2fdaf774b9.jpeg', 'Lucile Ortega - Photographie', 25),
(243, 'bbade3239c174f01287cbfe46c5339c7.jpeg', 'Lucile Ortega - Photographie', 25),
(244, '4f4b3bf6d31285e25a97b8cd041ad3bd.jpeg', 'Lucile Ortega - Photographie', 25),
(245, '2d74645067a7d4790344f676220e1edc.jpeg', 'Lucile Ortega - Photographie', 25),
(246, '0ea31823b1951b95a25d3961b1671fad.jpeg', 'Lucile Ortega - Photographie', 25),
(247, '1d447da7cb17b78abe2887a8ac9fa005.jpeg', 'Lucile Ortega - Photographie', 25),
(248, 'c45233e4c4d88ef2aeca2f5920ffea19.jpeg', 'Lucile Ortega - Photographie', 25),
(249, 'd90b253b27b0ad237627a4d72ede30f5.jpeg', 'Lucile Ortega - Photographie', 25),
(250, '65f2f094798c795723222b576718b8aa.jpeg', 'Lucile Ortega - Photographie', 25),
(251, '2df1ea8e07f1e5e9a1b4dcb23f14f356.jpeg', 'Lucile Ortega - Photographie', 25),
(252, '857809a79cf651f59d8abf1e66352dfa.jpeg', 'Lucile Ortega - Photographie', 25),
(253, '005be32834936fc65474198eb674a0a4.jpeg', 'Lucile Ortega - Photographie', 25),
(254, 'fbbef86e299447714f3934828ffaa2c2.jpeg', 'Lucile Ortega - Photographie', 25),
(255, 'ab51edb9a6c313ba4df6a08a91f7daad.jpeg', 'Lucile Ortega - Photographie', 25),
(256, 'd2ee28a877e9dac74eab7916d430ebf6.jpeg', 'Lucile Ortega - Photographie', 25),
(257, '3c87d633b064f150e4fe0292a3be4057.jpeg', 'Lucile Ortega - Photographie', 25),
(258, 'ee865fbf35bb4ef7ba3dbba54b4c4b74.jpeg', 'Lucile Ortega - Photographie', 25),
(259, '4f08e34e71c3cfa70e41a2f9fdbbf627.jpeg', 'Lucile Ortega - Photographie', 25),
(260, 'ed56cae8fb56fcee142310e80266715f.jpeg', 'Lucile Ortega - Photographie', 25),
(261, '87c54d4eab3215d65319d32fe84e97bb.jpeg', 'Lucile Ortega - Photographie', 25),
(262, 'c5b0159863b1c38572f1142f29bf36cc.jpeg', 'Lucile Ortega - Photographie', 25),
(263, '1ed5a215adcf44e6a295610716c62464.jpeg', 'Lucile Ortega - Photographie', 25),
(264, '1f5833141e2eda849e35d0edebb5cb9d.jpeg', 'Lucile Ortega - Photographie', 25),
(265, '9dc5c602891af688e427a3cdd643aa84.jpeg', 'Lucile Ortega - Photographie', 25),
(266, '8aa2db253b9111f614fb074b2f35d386.jpeg', 'Lucile Ortega - Photographie', 25),
(267, 'da6a90e49251b4e85b0445441d8c15ba.jpeg', 'Lucile Ortega - Photographie', 25),
(268, '88650c7034ac0db54c7ec2bdfc255794.jpeg', 'Lucile Ortega - Photographie', 25),
(269, 'ea5a59d9e9ee42c0a139159e66479f12.jpeg', 'Lucile Ortega - Photographie', 25),
(270, '69e3d5264d6c6f46146a9e8a00e0eddf.jpeg', 'Lucile Ortega - Photographie', 25),
(271, 'e165052ea217ac7281b49ac52878a809.jpeg', 'Lucile Ortega - Photographie', 25),
(272, '4e289595c5800646f114e7ddd426cf1d.jpeg', 'Lucile Ortega - Photographie', 25),
(273, '86b64e9c6a344df64937f8d8c6ff0e60.jpeg', 'Lucile Ortega - Photographie', 25),
(274, '18bb3a1e11b688301e80a7ddc90f49c6.jpeg', 'Lucile Ortega - Photographie', 25),
(275, '1f391c6a1a71e35b73c0e71c579cb6a7.jpeg', 'Lucile Ortega - Photographie', 25),
(276, '248088ec67caf16aa54ea7f7ed3fc0f9.jpeg', 'Lucile Ortega - Photographie', 25),
(277, '68ce353cc2a3809719e43127049900cd.jpeg', 'Lucile Ortega - Photographie', 25),
(278, '1bd7c67d253d3565bee942c25eca9144.jpeg', 'Lucile Ortega - Photographie', 25),
(279, '7781ec2b16bdbfabd268d68bd61f342c.jpeg', 'Lucile Ortega - Photographie', 25),
(280, 'caa7f630b3cd0fedb1031274410e4f6b.jpeg', 'Lucile Ortega - Photographie', 25),
(281, 'ba9c2f4badcdba92ced343c6a5e5db23.jpeg', 'Lucile Ortega - Photographie', 25),
(282, 'c940d7eca373fd7afd4f7c6dad5401c1.jpeg', 'Lucile Ortega - Photographie', 25),
(283, '7f4f6f72f6993dbda74ac025a2d849a8.jpeg', 'Lucile Ortega - Photographie', 25),
(284, '5171989df76173df8a51d0ec8192f652.jpeg', 'Lucile Ortega - Photographie', 25),
(285, '742673f60c0a8bfe554c94ec61915338.jpeg', 'Lucile Ortega - Photographie', 25),
(286, '84b2647b18bb69156685d6cd3b17dc7a.jpeg', 'Lucile Ortega - Photographie', 25),
(287, '94eb87a43db9a007a608c3a38eb1d241.jpeg', 'Lucile Ortega - Photographie', 25),
(288, '4f6306fea3d778d1238307e25a11e6cf.jpeg', 'Lucile Ortega - Photographie', 25),
(289, '785a4186b32e93f96418e89accc4ee27.jpeg', 'Lucile Ortega - Photographie', 25),
(290, 'ec0b4f66862f6de8bfa5e521c9c397b5.jpeg', 'Lucile Ortega - Photographie', 25),
(291, '47e3e390ac275253aba898d2d187a438.jpeg', 'Lucile Ortega - Photographie', 25),
(292, '286f22c6091957471c7b976c2d1184d5.jpeg', 'Lucile Ortega - Photographie', 25),
(293, 'facb5912b04e9159b06bbef6c4864fcb.jpeg', 'Lucile Ortega - Photographie', 25),
(294, '0fdcecb4584c3f0afc059fa1d889d165.jpeg', 'Lucile Ortega - Photographie', 25),
(295, '49924368a2f25811350793e094826727.jpeg', 'Lucile Ortega - Photographie', 25),
(296, '435e496666c5270d78ced32d87bcbcb9.jpeg', 'Lucile Ortega - Photographie', 25),
(297, '4c53042e2489fd20f1010925ed5b2481.jpeg', 'Lucile Ortega - Photographie', 25),
(298, '585cc83cb374a0cd7f46030cb2da7103.jpeg', 'Lucile Ortega - Photographie', 25),
(299, '4a25461919ff0f3bde5789d6737f7e35.jpeg', 'Lucile Ortega - Photographie', 25),
(300, '8dec52f4fc46e47644a6e9acc14dfccc.jpeg', 'Lucile Ortega - Photographie', 25),
(301, 'b127068c87365b12cb55b730db69da1b.jpeg', 'Lucile Ortega - Photographie', 25),
(302, 'c8cfd3957ab7fb4ae93cd955b69eb8f6.jpeg', 'Lucile Ortega - Photographie', 25),
(303, '975ccc3692f1d1add371b20fd2c105d5.jpeg', 'Lucile Ortega - Photographie', 25),
(305, 'c88e761350184994450004eb7ce23718.jpeg', 'Lucile Ortega - Photographie', 26),
(306, 'a033adc5c88150be659573626f8a69bb.jpeg', 'Lucile Ortega - Photographie', 26),
(307, 'c8cb0e2d6eef1a154da4e073a86beb88.jpeg', 'Lucile Ortega - Photographie', 26),
(308, '09ccf6ec8407673d6a6553ad7f639842.jpeg', 'Lucile Ortega - Photographie', 26),
(309, '4f301c35c22e10138187a6b6ee9e92d6.jpeg', 'Lucile Ortega - Photographie', 26),
(310, '5a36e183f0a99fbfb383a29f4ea2cc52.jpeg', 'Lucile Ortega - Photographie', 26),
(311, 'cecbc8b5985a5b11da3c9bdabd071626.jpeg', 'Lucile Ortega - Photographie', 26),
(312, 'd843b8d81151caa8214715408c143ef7.jpeg', 'Lucile Ortega - Photographie', 26),
(313, 'a4e12f9b2fd16dde2410772d4065d39f.jpeg', 'Lucile Ortega - Photographie', 26),
(314, '5863817ab77f24d5dfbac13758f4b569.jpeg', 'Lucile Ortega - Photographie', 26),
(315, '11abca157f7a6c43f2c0fb998a65e552.jpeg', 'Lucile Ortega - Photographie', 26),
(316, 'd85e035360662cd9001fa9460d71256b.jpeg', 'Lucile Ortega - Photographie', 26),
(317, '1e6c3718845b43e0a4acc5a12b5a7408.jpeg', 'Lucile Ortega - Photographie', 26),
(318, '5eee6ec6c1fb38a9bdc8b418a34468e5.jpeg', 'Lucile Ortega - Photographie', 26),
(319, 'f12e84d189a74804cefe5c902bd6d50f.jpeg', 'Lucile Ortega - Photographie', 26),
(320, '6d96eefe25ad54dd779dd39e176050c1.jpeg', 'Lucile Ortega - Photographie', 26),
(321, 'e72979b2d8e6236db28f997c2ea55bef.jpeg', 'Lucile Ortega - Photographie', 26),
(322, 'd50f1960089a2aa34bb99d571d4edfa7.jpeg', 'Lucile Ortega - Photographie', 26),
(323, '2ecc07ba74c063be4c5b183265fa934f.jpeg', 'Lucile Ortega - Photographie', 26),
(324, '652ef3d660bd37a9a4874fde302d87f1.jpeg', 'Lucile Ortega - Photographie', 26),
(325, '85a4cb319ada814b34b7b39fab517c62.jpeg', 'Lucile Ortega - Photographie', 26),
(326, '0fcf6548cdabef059e847326ec6f7c03.jpeg', 'Lucile Ortega - Photographie', 26),
(327, '9dcfef355b6cc956576ac5ccb489e702.jpeg', 'Lucile Ortega - Photographie', 26),
(328, 'cbfc0f0047585b2552d41002e909e7cf.jpeg', 'Lucile Ortega - Photographie', 26),
(329, 'fc79035a82a34588c420cb892f5bcf6f.jpeg', 'Lucile Ortega - Photographie', 26),
(330, 'df88844d8a74f57d312e26ae263515c0.jpeg', 'Lucile Ortega - Photographie', 26),
(331, '36ed6d3147c116660ea6db65b5688f07.jpeg', 'Lucile Ortega - Photographie', 26),
(332, '08b35438d526a15eb0ddee6768656ebd.jpeg', 'Lucile Ortega - Photographie', 26),
(333, '414f96eca77c196cd28a4757e9e15b8e.jpeg', 'Lucile Ortega - Photographie', 26),
(334, '07ac328d92ea7303449fbbd8afeeb56d.jpeg', 'Lucile Ortega - Photographie', 26),
(335, 'e13638c1c474c5cc95ae72e9f72aecf7.jpeg', 'Lucile Ortega - Photographie', 26),
(336, '2316d932a0edb7687d8ee6359da8e2f8.jpeg', 'Lucile Ortega - Photographie', 26),
(337, '3739650da88e254c7def69fc9c5269a0.jpeg', 'Lucile Ortega - Photographie', 26),
(338, '0465f6f5b5c7e6672f72ab13d38b8478.jpeg', 'Lucile Ortega - Photographie', 26),
(339, '46516f79c427e70e591685bd51412a5e.jpeg', 'Lucile Ortega - Photographie', 26),
(340, '177ecb2946824b61320770a758f6afd4.jpeg', 'Lucile Ortega - Photographie', 26),
(341, '80e52193b720e8f99a6b593fdebb772d.jpeg', 'Lucile Ortega - Photographie', 26),
(342, 'cb573b94ddf9e58396cb18e82c476852.jpeg', 'Lucile Ortega - Photographie', 26),
(343, '8bc0e752392ce6fa44ad52cff8c5dea1.jpeg', 'Lucile Ortega - Photographie', 26),
(344, 'e469cd76c6f54170ea57a668d3e81bcd.jpeg', 'Lucile Ortega - Photographie', 26),
(345, '86e2bb2e1d651375e2e0fc13464c8e60.jpeg', 'Lucile Ortega - Photographie', 26),
(346, 'f2cc97872ac8b18fa5546ce7d9acbd64.jpeg', 'Lucile Ortega - Photographie', 26),
(347, 'e217ba9dce37c79389a88a26cfa41fbd.jpeg', 'Lucile Ortega - Photographie', 26),
(348, '4ff0d7ec93b49ff3d54db99aa177d0d9.jpeg', 'Lucile Ortega - Photographie', 26),
(349, 'e088384ffc8dbc1be17b6534ef57a181.jpeg', 'Lucile Ortega - Photographie', 26),
(350, 'b2f7a74428a4ea96c089d327b48824fb.jpeg', 'Lucile Ortega - Photographie', 26),
(351, '9f4b281bf171418a41907a255735f306.jpeg', 'Lucile Ortega - Photographie', 26),
(352, 'c034c01406d21f99eb8897e72e086234.jpeg', 'Lucile Ortega - Photographie', 26),
(353, 'dd7be8bc32751f52929978eb11ecd93d.jpeg', 'Lucile Ortega - Photographie', 26),
(354, '520640fcca4ab12cbbe9ee75b43cee9a.jpeg', 'Lucile Ortega - Photographie', 26),
(355, 'fea01003cfc6de407e87e71fa38ec40f.jpeg', 'Lucile Ortega - Photographie', 26),
(356, 'e6c0346c0731c07f9e5d1103ed59f4cc.jpeg', 'Lucile Ortega - Photographie', 26),
(357, '0421beacabe0a852e762cd6cbf61ef0d.jpeg', 'Lucile Ortega - Photographie', 26),
(358, '297f6b5903e917b30adfa927eb055bcd.jpeg', 'Lucile Ortega - Photographie', 26),
(359, '3cc6e0186efbc4a222d3285cdff7efe1.jpeg', 'Lucile Ortega - Photographie', 26),
(360, 'dff395135cbee65460508831b82e87fa.jpeg', 'Lucile Ortega - Photographie', 26),
(361, '797cda76fdb64b729f68dcdf5eb18b5a.jpeg', 'Lucile Ortega - Photographie', 26),
(362, 'ff4ccd160807b3c1b7556082e3712637.jpeg', 'Lucile Ortega - Photographie', 26),
(363, '419e49e6aacd78c312cb3d4fd55d28e3.jpeg', 'Lucile Ortega - Photographie', 26),
(364, 'd1164998a45c7bfb2db44d06d03b4440.jpeg', 'Lucile Ortega - Photographie', 26);

-- --------------------------------------------------------

--
-- Structure de la table `lien`
--

CREATE TABLE IF NOT EXISTS `lien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ordre` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) TYPE=InnoDB AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `page`
--

CREATE TABLE IF NOT EXISTS `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tags` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `publication` tinyint(1) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_140AB620989D9B62` (`slug`)
) TYPE=InnoDB  AUTO_INCREMENT=25 ;

--
-- Contenu de la table `page`
--

INSERT INTO `page` (`id`, `tags`, `slug`, `content`, `publication`, `title`) VALUES
(11, NULL, 'partenaires', '<p class="Style9" style="text-align: center;">Partenaires :</p>\r\n<p class="Style9" style="text-align: center;"><span style="color: #cc99ff;"><a style="color: #cc99ff;" href="http://www.metsdelicestraiteur.fr/" target="new">Mets D&eacute;lices</a></span> traiteur</p>\r\n<p class="Style9" style="text-align: center;"><span style="color: #cc99ff;"><a style="color: #cc99ff;" href="http://www.jackelentraiteur.com/" target="new">JackElen</a></span> traiteur</p>\r\n<p class="Style9" style="text-align: center;"><span style="color: #cc99ff;"><a style="color: #cc99ff;" href="http://www.djmcdean.fr/" target="new">Alex McDean</a></span> Dj</p>\r\n<p class="Style9" style="text-align: center;"><span style="color: #cc99ff;"><a style="color: #cc99ff;" href="http://juliensecret.wix.com/creation-video" target="new">Julien Secret</a></span> cr&eacute;ation vid&eacute;o</p>\r\n<p class="Style9" style="text-align: center;"><span style="color: #cc99ff;"><a style="color: #cc99ff;" href="http://www.votre-chateau-de-famille.com/fr-fr/carte-et-chateaux/chateau-des-gaudras" target="new">Ch&acirc;teau des Gaudras</a></span></p>\r\n<p class="Style9" style="text-align: center;"><a href="http://www.sdrproduction.fr/" target="new"><span style="color: #cc99ff;">SDR Production</span> </a>cr&eacute;ation vid&eacute;o</p>\r\n<p class="Style9" style="text-align: center;">&nbsp;</p>\r\n<p class="Style9" style="text-align: center;">Clients :</p>\r\n<p class="Style9" style="text-align: center;"><a href="http://www.ardechegrandair.com/" target="_blank" rel="noopener noreferrer"><span style="color: #cc99ff;">Office de tourisme</span> </a>Ard&egrave;che grand air</p>\r\n<p class="Style9" style="text-align: center;"><a href="http://www.vivarhone.fr/" target="_blank" rel="noopener noreferrer"><span style="color: #cc99ff;">Vivarhone</span> </a>Communaut&eacute; de communes</p>\r\n<p class="Style9" style="text-align: center;"><span style="color: #cc99ff;"><a style="color: #cc99ff;" href="http://www.mairie-annonay.fr/" target="_blank" rel="noopener noreferrer">Ville D''Annonay</a></span></p>\r\n<p class="Style9" style="text-align: center;"><span style="color: #cc99ff;"><a style="color: #cc99ff;" href="http://www.domainecheze.com/" target="new">Domaine Louis Ch&egrave;ze</a></span> Viticulteur</p>', 1, 'Partenaires'),
(17, NULL, 'formations', '<p class="Style2 Style8 Style10"><u>Fomations et cours particuliers:</u></p>\r\n<p>Si le monde de la photo vous interesse, vous pourrez d&eacute;couvrir les m&eacute;thodes de prise de vue (cadrage, composition, gestion de mod&egrave;les...), apprendre &agrave; ma&icirc;triser votre appareil photo et en tirer le meilleur partie. Si vous avez envie de d&eacute;couvrir photoshop ou de compl&eacute;ter vos connaissances en terme de retouches et montages photo, traitement de l''image, r&eacute;alisation de supports visuels, je vous propose des formations personnalis&eacute;es pour apprendre les secrets de l''image num&eacute;rique. Les cours individuels vous premettront d''avancer &agrave; votre rythme.</p>\r\n<p class="Style2 Style8 Style10"><u>Interventions collectives:</u></p>\r\n<p>Je propose &eacute;galement des cours collectifs et interventions (encadrement de projets photo...) pour associations, MJC, &eacute;tablissements scolaires...</p>\r\n<p>N''h&eacute;sitez pas &agrave; me contacter pour &eacute;tablir un programme et conna&icirc;tre les tarifs!</p>\r\n<p>&nbsp;</p>\r\n<p class="Style2 Style8" align="right"><u><span class="Style10">Me contacter</span></u><span class="Style10"><u>:</u></span></p>\r\n<p class="Style9" align="right">Pour tous renseignements n''h&eacute;sitez pas &agrave; me contacter, je me ferai un plaisir de vous r&eacute;pondre:</p>\r\n<p class="Style9" align="right"><a href="mailto:lucile.ortega@gmail.com">lucile.ortega@gmail.com</a></p>\r\n<p class="Style9" align="right">06.89.79.75.81</p>', 0, 'Formations');

-- --------------------------------------------------------

--
-- Structure de la table `user_admin`
--

CREATE TABLE IF NOT EXISTS `user_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(180) NOT NULL,
  `username_canonical` varchar(180) NOT NULL,
  `email` varchar(180) NOT NULL,
  `email_canonical` varchar(180) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `confirmation_token` varchar(180) DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext NOT NULL COMMENT '(DC2Type:array)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_6ACCF62E92FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_6ACCF62EA0D96FBF` (`email_canonical`),
  UNIQUE KEY `UNIQ_6ACCF62EC05FB297` (`confirmation_token`)
) TYPE=InnoDB  AUTO_INCREMENT=5 ;

--
-- Contenu de la table `user_admin`
--

INSERT INTO `user_admin` (`id`, `username`, `username_canonical`, `email`, `email_canonical`, `enabled`, `salt`, `password`, `last_login`, `confirmation_token`, `password_requested_at`, `roles`) VALUES
(1, 'greg', 'greg', 'greg@trucs2papas.fr', 'greg@trucs2papas.fr', 1, NULL, '$2y$13$kbzJyL4WfYZ53IISlO0VJ.kr7XT296NR8hkpk1t8qteDZcRJCGRAO', '2017-04-06 09:08:01', NULL, NULL, 'a:1:{i:0;s:16:"ROLE_SUPER_ADMIN";}'),
(2, 'grinch', 'grinch', 'ze_grinch07@hotmail.com', 'ze_grinch07@hotmail.com', 1, NULL, '$2y$13$faF0xjaqTyHdefCwMwhU/OU7isBKsTZYBqeLk4gGrgNi/xSgcEHli', '2017-04-04 12:17:30', NULL, NULL, 'a:1:{i:0;s:11:"ROLE_CLIENT";}'),
(3, 'lucile', 'lucile', 'lucile.ortega@gmail.com', 'lucile.ortega@gmail.com', 1, NULL, '$2y$13$hERwkRvEIqX0Pz/h2Wwip.l4F.s7Fcwbev9u4QR0UpkGIuwxYpTqK', '2017-04-06 12:30:15', NULL, NULL, 'a:1:{i:0;s:10:"ROLE_ADMIN";}'),
(4, 'mentor', 'mentor', 'adresse@bidon.fr', 'adresse@bidon.fr', 1, NULL, '$2y$13$NYU8hHB/fWjleX37ezDIX.wmKCsxw.bemTePmI34wUFxaDmm3xo2e', '2017-04-05 19:09:17', NULL, NULL, 'a:1:{i:0;s:10:"ROLE_ADMIN";}');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `galerie_image`
--
ALTER TABLE `galerie_image`
  ADD CONSTRAINT `FK_94BB0BC93DA5256D` FOREIGN KEY (`image_id`) REFERENCES `image` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_94BB0BC9825396CB` FOREIGN KEY (`galerie_id`) REFERENCES `galerie` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `FK_C53D045F825396CB` FOREIGN KEY (`galerie_id`) REFERENCES `galerie` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
